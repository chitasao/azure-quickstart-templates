configuration FixEnvVariable
{
    Node localhost
    {
        Script PSModulePath
        {
            SetScript = {
                try
                {
                    $vars = $env:PSModulePath -split ';'
                    $vars = ($vars | ForEach-Object {$_.trim('\')}) | Select-Object -unique;
                    $vars = $vars -join ';';
                    [Environment]::SetEnvironmentVariable("PSModulePath", $vars, "Machine")
                    return $true;
                }
                catch{
                    return $false;
                }
            }
            
            TestScript = {
                $vars = $env:PSModulePath -split ';'
                $vars = ($vars | ForEach-Object {$_.trim('\')}) | Select-Object -unique;
                $vars = $vars -join ';';
                return ($vars -eq $env:PSModulePath);
            }

            
        }
    }
}

