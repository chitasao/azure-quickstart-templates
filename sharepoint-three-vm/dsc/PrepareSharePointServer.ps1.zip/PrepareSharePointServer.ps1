#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration PrepareSharePointServer
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DNSServer,
        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )
    #Install-Module xComputerManagement;
    Import-DscResource -ModuleName xComputerManagement
    Import-DscResource -ModuleName xDisk;
    Import-DscResource -ModuleName cDisk;
    Import-DscResource -ModuleName xNetworking;
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }
        cDiskNoRestart SPDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitforDisk]Disk2"
        }
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            DependsOn = "[cDiskNoRestart]SPDataDisk"
        }
        xDnsServerAddress DnsServerAddress
        {
            Address        = $DNSServer
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn="[WindowsFeature]ADPS"
        }
    }
}

